"""Application configuration and settings."""
