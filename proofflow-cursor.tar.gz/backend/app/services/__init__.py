"""Domain services (storage, thumbnails, shares)."""
