"""Utility helpers (security, ids, filenames)."""
