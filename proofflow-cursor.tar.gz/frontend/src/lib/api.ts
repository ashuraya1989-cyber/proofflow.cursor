import { getAdminToken } from "./storage";

export type Album = {
  id: string;
  name: string;
  created_at: string;
};

export type Subfolder = {
  id: string;
  album_id: string;
  name: string;
  created_at: string;
};

export type Image = {
  id: string;
  album_id: string;
  subfolder_id: string;
  filename: string;
  width: number;
  height: number;
  created_at: string;
  thumb_url: string;
  preview_url: string;
  image_url: string;
};

export type Share = {
  id: string;
  album_id: string;
  subfolder_id: string | null;
  created_at: string;
  expires_at: string | null;
  url: string;
};

export type ShareScope = {
  id: string;
  album_id: string;
  subfolder_id: string | null;
  mode: "album_all_subfolders" | "single_subfolder";
  title: string;
};

export type ShareAuth = {
  token: string;
  token_expires_at: string;
};

const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

async function fetchJson(path: string, options?: RequestInit) {
  const token = getAdminToken();
  const headers: Record<string, string> = {
    ...options?.headers as any,
  };

  if (token && !headers["Authorization"]) {
    headers["X-Admin-Token"] = token;
  }
  
  if (!headers["Content-Type"] && !options?.body) {
    headers["Content-Type"] = "application/json";
  } else if (!headers["Content-Type"] && options?.body && typeof options.body === "string") {
     headers["Content-Type"] = "application/json";
  }

  const url = `${BASE_URL}${path}`;
  const res = await fetch(url, { ...options, headers });
  
  if (!res.ok) {
    let msg = res.statusText;
    try {
      const body = await res.json();
      if (body.detail) msg = body.detail;
    } catch {
      // ignore
    }
    throw new Error(msg);
  }

  return res.json();
}

export const api = {
  admin: {
    listAlbums: () => fetchJson("/api/admin/albums") as Promise<Album[]>,
    createAlbum: (name: string) => fetchJson("/api/admin/albums", {
      method: "POST",
      body: JSON.stringify({ name }),
    }) as Promise<Album>,
    
    listSubfolders: (albumId: string) => fetchJson(`/api/admin/subfolders?album_id=${albumId}`) as Promise<Subfolder[]>,
    createSubfolder: (albumId: string, name: string) => fetchJson("/api/admin/subfolders", {
      method: "POST",
      body: JSON.stringify({ album_id: albumId, name }),
    }) as Promise<Subfolder>,
    
    listImages: (albumId: string, subfolderId?: string | null) => {
      let q = `?album_id=${albumId}`;
      if (subfolderId) q += `&subfolder_id=${subfolderId}`;
      return fetchJson(`/api/admin/images${q}`) as Promise<Image[]>;
    },
    
    createShare: (albumId: string, subfolderId: string | null, password: string) => fetchJson("/api/admin/shares", {
        method: "POST",
        body: JSON.stringify({ album_id: albumId, subfolder_id: subfolderId, password }),
      }) as Promise<Share>,
  },
  
  share: {
      getMeta: (shareId: string) => fetchJson(`/api/shares/${shareId}/meta`) as Promise<ShareScope>,
      auth: (shareId: string, password: string) => fetchJson(`/api/shares/${shareId}/auth`, {
          method: "POST",
          body: JSON.stringify({ password })
      }) as Promise<ShareAuth>,
      listImages: (shareId: string, token: string) => fetchJson(`/api/shares/${shareId}/images`, {
          headers: { Authorization: `Bearer ${token}` }
      }) as Promise<Image[]>
  }
};
