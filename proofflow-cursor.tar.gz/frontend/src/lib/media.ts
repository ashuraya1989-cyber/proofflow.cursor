import { getAdminToken, getShareToken } from "./storage";

export function adminMedia(path: string): string {
  if (!path) return "";
  const token = getAdminToken();
  if (!token) return path;
  
  const separator = path.includes("?") ? "&" : "?";
  return `${path}${separator}admin=${encodeURIComponent(token)}`;
}

export function shareMedia(path: string, shareId: string): string {
  if (!path || !shareId) return path || "";
  const token = getShareToken(shareId);
  if (!token) return path;
  
  const separator = path.includes("?") ? "&" : "?";
  return `${path}${separator}t=${encodeURIComponent(token)}`;
}
