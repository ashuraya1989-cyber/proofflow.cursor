
const TOKEN_KEY = "pf_admin_token";
const SHARE_PREFIX = "pf_share_";

export function getAdminToken(): string {
  try {
    return localStorage.getItem(TOKEN_KEY) || "";
  } catch {
    return "";
  }
}

export function setAdminToken(token: string) {
  try {
    if (!token) localStorage.removeItem(TOKEN_KEY);
    else localStorage.setItem(TOKEN_KEY, token);
  } catch {
    // ignore
  }
}

export function getShareToken(shareId: string): string {
  try {
    return localStorage.getItem(SHARE_PREFIX + shareId) || "";
  } catch {
    return "";
  }
}

export function setShareToken(shareId: string, token: string) {
  try {
     if (!token) localStorage.removeItem(SHARE_PREFIX + shareId);
     else localStorage.setItem(SHARE_PREFIX + shareId, token);
  } catch {
    // ignore
  }
}
