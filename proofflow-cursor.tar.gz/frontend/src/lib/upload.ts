import { getAdminToken } from "./storage";

type UploadResult = { ok: true } | { ok: false; error: string };

type UploadOptions = {
  albumId: string;
  subfolderId: string;
  file: File;
  onProgress: (pct: number) => void;
};

const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

export function uploadSingleImage({ albumId, subfolderId, file, onProgress }: UploadOptions): Promise<UploadResult> {
  return new Promise((resolve) => {
    const xhr = new XMLHttpRequest();
    const token = getAdminToken();
    
    // Using bulk_upload endpoint but sending just one file
    const url = `${BASE_URL}/api/admin/upload?album_id=${albumId}&subfolder_id=${subfolderId}`;
    
    xhr.open("POST", url);
    if (token) {
      xhr.setRequestHeader("X-Admin-Token", token);
    }
    
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        const pct = Math.round((e.loaded / e.total) * 100);
        onProgress(pct);
      }
    };
    
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve({ ok: true });
      } else {
        let msg = xhr.statusText;
        try {
           const body = JSON.parse(xhr.responseText);
           if (body.detail) msg = body.detail;
        } catch {
            // ignore
        }
        resolve({ ok: false, error: msg });
      }
    };
    
    xhr.onerror = () => {
      resolve({ ok: false, error: "Network error" });
    };
    
    const fd = new FormData();
    fd.append("files", file); // Backend expects 'files' list
    
    xhr.send(fd);
  });
}
